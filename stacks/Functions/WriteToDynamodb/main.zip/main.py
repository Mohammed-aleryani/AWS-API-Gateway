import json
import urllib.parse
import boto3
from datetime import datetime, timedelta

print('Loading function')

s3 = boto3.client('s3')
dynamodb = boto3.client('dynamodb')


def lambda_handler(event, context):
    print("Received event: " + json.dumps(event, indent=2))

    # Get the object from the event and show its content type
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.parse.unquote_plus(event['Records'][0]['s3']['object']['key'], encoding='utf-8')

    key_arr = key.split('/')
    customer_id = key_arr[1]
    file_name = key_arr[2]
    writeToDyanmodb(customer_id, file_name, key)


def writeToDyanmodb(customer_id, file_name, key):
    expiration_time = str((datetime.now() + timedelta(days=30)).timestamp())
    try:
        dynamodb.put_item(
            TableName='customers',
            Item={
                'customer_id': {"S": str(customer_id)},
                "file_name": {"S": str(file_name)},
                "key": {"S": str(key)},
                "expiration_time": {"N": expiration_time}
            }
        )
    except Exception as e:
        print(e)
        raise e
