import json
import boto3

s3 = boto3.client('s3')

print('Loading function')


def lambda_handler(event, context):
    record = event['Records'][0]
    print(record['eventName'])
    if record['eventName'] == 'REMOVE':
        file_name = event['Records'][0]['dynamodb']['OldImage']['key']['S']
        try:
            s3.delete_object(
                Bucket='customer-1996',
                Key=file_name
            )

        except Exception as e:
            raise e

